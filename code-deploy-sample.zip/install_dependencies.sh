#!/bin/bash
apt-get -y install apache2